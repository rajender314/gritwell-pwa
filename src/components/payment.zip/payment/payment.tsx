import React, {useMemo} from 'react';
import {
  useStripe,
  useElements,
  CardNumberElement,
  CardCvcElement,
  CardExpiryElement,
} from '@stripe/react-stripe-js';
import {currencyFormat, PaymentSuccess} from '@app/utils';
import Button from '../button';
import {PaymentForm, CardDetails, ExpiryDate, Cvv, CardHolderName,
  CardError, FooterButtonContainer} from './payment-componnets';
import {Description} from '../layout-onBoarding/layout-onBoarding-components';
import {appFontColor, color8, color9} from '@app/styles';
import {Mixpanel} from '@app/App';
import {action} from '@app/mixpanel/Service';
import {gaAction} from '@app/googleAnalytics/googleAnalytics';
import gtag from 'ga-gtag';

type PaymentProps = {
    amount: number;
    tokenId: any;
    onCancel: (e: any) => void;
    transactionPayment: any;
    paymentStatus?: PaymentSuccess;
    saveCard?: any;
    disMsg :any
  };

const useOptions = () => {
  const options = useMemo(
      () => ({
        style: {
          base: {
            'fontSize': '16px',
            'color': appFontColor,
            'letterSpacing': '0.025em',
            '::placeholder': {
              color: color8,
            },
          },
          invalid: {
            color: color9,
          },
        },
      }),
      [],
  );

  return options;
};
/**
 *
 * @return {paymentcomponent} global component
  */
export default function Payment({
  amount,
  onCancel,
  tokenId,
  transactionPayment,
  saveCard,
  disMsg,
}: PaymentProps) {
  const dollar: string = '$';
  const [cardHolderName, setCardHolderName] = React.useState('');
  const stripe: any = useStripe();
  const elements: any = useElements();
  const options = useOptions();
  const [paymentText, updatePaymentText] = React.useState('Pay Now');
  const [, updateIsSubmitted] = React.useState(false);
  const [cardError, updateCardError] = React.useState('');
  const [makeDefa, updateMakeDef] = React.useState(false);

  /**
   *
   * @param {event} event to make payment
   */
  const makePayment = async (event: any) => {
    updateIsSubmitted(true);
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }
    const cardNumber = elements.getElement(CardNumberElement);
    let tokenKey ='';
    stripe.createToken(cardNumber).then(function(result) {
      tokenKey = result.token.id;
      if (tokenKey) {
        tokenId({token_Key: tokenKey,
          is_def: makeDefa});
      }
    });
    if (cardNumber) {
      const payload = await stripe.createPaymentMethod({
        type: 'card',
        card: cardNumber,
      });
      if (payload.error || !cardHolderName) {
        updateCardError(
          payload.error ?
            payload.error.message :
            'Please enter card holder name',
        );
        updateIsSubmitted(false);
        updatePaymentText('Pay Now');
      } else {
        updatePaymentText('Processing...');
        // const paymentStatus = await
        // transactionPayment(payload, cardHolderName, tokenKey);
        // if (paymentStatus) {
        //   updateIsSubmitted(false);
        // }
      }
    }
  };

  /**
   *
   * @param {event} event update error message
   * @param {type} type update error message
   */
  function onCardChange(event: any, type?: string) {
    updateCardError('');

    if (type === 'holderName') {
      setCardHolderName(event.target.value);
    }
  }
  return (
    <PaymentForm>
      <Description className='mt-15'>Card number</Description>
      <CardNumberElement
        options={options}
        onChange={(e: any) => onCardChange(e)}
      />
      <CardDetails>
        <ExpiryDate>
          <Description>Expiry date</Description>
          <CardExpiryElement
            options={options}
            onChange={(e: any) => onCardChange(e)}
          />
        </ExpiryDate>
        <Cvv>
          <Description>CVV / CVC</Description>
          <CardCvcElement
            options={options}
            onChange={(e: any) => onCardChange(e)}
          />
        </Cvv>
      </CardDetails>
      <CardDetails>
        <ExpiryDate>
          <Description>Card Holder Name</Description>
          <CardHolderName
            value={cardHolderName}
            placeholder="Enter card holder name"
            onChange={(e) => onCardChange(e, 'holderName')}></CardHolderName>
        </ExpiryDate>
        {!saveCard ? <Cvv>
          <Description>Amount</Description>
          <CardHolderName
            value={`${dollar}${currencyFormat(amount)}`}
            disabled={true}></CardHolderName>
        </Cvv> : null}
      </CardDetails>
      <CardError>{cardError}</CardError>
      <div className='d-flex gap-5 my-22' onClick={()=>{
        updateMakeDef(!makeDefa);
      }}>
        <input type='checkbox' checked={makeDefa}/>
        <Description className='m-0'>Save card as default</Description>
      </div>
      <FooterButtonContainer >
        {/* <CancelPayment onClick={onCancel}>Cancel</CancelPayment> */}
        {!saveCard ? <Button
          variant="primary"
          onClick={(e: any) => {
            makePayment(e);
            Mixpanel.track(
                action['payment']['payNow']['title'],
                action['payment']['payNow']['props']);
            gtag('event',
                gaAction['payment']['payNow']['title'], {
                  'event-category':
                gaAction['payment']['payNow']['category'],
                });
          }}>
          {paymentText}
        </Button> :
        <Button
          variant="primary"
          onClick={(e: any) => {
            makePayment(e);
            Mixpanel.track(
                action['payment']['addCard']['title'],
                action['payment']['addCard']['props']);
            gtag('event',
                gaAction['payment']['addCard']['title'], {
                  'event-category':
                gaAction['payment']['addCard']['category'],
                });
          }}>
          Add Card
        </Button>
        }
      </FooterButtonContainer>

    </PaymentForm>
  );
}
